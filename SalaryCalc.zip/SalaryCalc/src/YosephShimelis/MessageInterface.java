package YosephShimelis;
public interface MessageInterface {
    public void showMessages();   
}
