package YosephShimelis;
public class salary extends Employee {


    private double time;
    private double salary;
  
    public salary (String name, int age, int position, double time){
        super (name,age,position);
        setTime(time);
        setSalary();
    }
    
    public void display(){
        System.out.println("============================");
        System.out.println("Name: " + getName());
        System.out.println("Age: " + getAge());
        System.out.println("Position: "  + getPosition());
        System.out.println("Wage: "  +  getWage());
        System.out.println("Time Worked: "  + getTime());
        System.out.println("Salary: "   + getSalary());
    }
    public double getTime(){

        return time;
    }

    public void setTime(double time){
        this.time=time;
    }
    public double getSalary(){
        return  salary;
    }
    public void setSalary(){
        salary= getTime()* getWage();
    }  
}

    

