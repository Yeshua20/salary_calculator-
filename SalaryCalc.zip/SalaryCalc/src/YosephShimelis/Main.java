
package YosephShimelis;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Bonus Bo = new Bonus();
        
        
        
        
        Scanner s1 = new Scanner(System.in);
        Scanner s2 = new Scanner(System.in);
        System.out.println("'\f' Welcome To Salary Computation Program");
        System.out.println("Enter Number of Employees");
        int length = s1.nextInt();
       
        
        // input taking way
        salary[] sal = new salary[length];
        
        
        
        for (int i = 0; i < length; i++) {
            System.out.println("Enter Name");
            String name = s2.nextLine();
            System.out.println("Enter Age");
            int age = s1.nextInt();
            System.out.println("Enter Position (1) Manager (2) Service Crew");
            int position = s1.nextInt();
            System.out.println("Enter Hrs Worked");
            double time = s1.nextDouble();
            
            
            Msg m= new Msg();
            m.showMessages();
            
            
            if (age < 18) {
                System.out.println("Minor");
                break;
            }
            if (time > 24) {
                System.out.println("Out of Range");
                break;
            }
            sal[i] = new salary (name, age, position, time);

        }

        for (int i = 0; i < length; i++) {
            sal[i].display();
            
            System.out.println("Please Enter The Check in Time:");
            double checkT = s1.nextDouble();
            switch ((int) checkT) {
                case 0:
                    System.out.println("Invalid Time Format");
                    break;
                case 1:
                    System.out.println("Invalid Entry Hasn't Opened At that Instance");
                    break;
                case 2:
                    System.out.println("For Your Proffesionalism Your Awarded increase Percent: " + Bo.calculate_overtime() * checkT);
                    break;
                case 3:
                    System.out.println("Please Be Punctual: ");
                    break;
                case 4:
                    System.out.println("BE PUNCTUAL!!! Following Percent will Be Taken Away " + Bo.calculate_overtime() * checkT);
                    break;

                default:
                    System.out.println("Please Take your salary and leave, Your Suspended For Unlimited Time.");
    }
}
    }
    }
    

