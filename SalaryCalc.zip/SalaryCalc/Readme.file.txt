project By: Yoseph Shimelis 
Instructor Name: Mr. Sidrak
Project Name: SalaryComputation Calculator


The Project?
The project calculates salary by taking age,name position of the worker and using the help of default assigned Wage values.
The project Doesnt Allow under age 18 to work so it will yield a response of Minor as an exception.
The project also calculates In 24 Hr range only.
The project have punctuality as its core and gives pay rise as well as fires those who are punctual and late respectivelt. 

How to run?
You can run this project From the Class Main
the classes are under package SalaryCalculator in src folder.

OOP's principles?

Abstraction:- I implemented an interface inorder to response to punctuality of the worker
              I extended an abstract class inorder to give bonus payrise to punctual workers

Polymorphism:- During implmentation of interface we have overridenn it which gives us Run-time Dynamic Polymorphism
               During extending of abstract class we have overridden it which gives us Run-time Dynamic Polymorphism

Inheritance:- All the classes are related with eachother in some manner 
              one class inherits the property of the other and the sub-class may add its own Attribute after inheriting

Encapsulation:- I have binded a code with a Data to protect Manipulation from outside world.
                To Achieve this I have given certain variables a privilidge of being Private Branded.

     