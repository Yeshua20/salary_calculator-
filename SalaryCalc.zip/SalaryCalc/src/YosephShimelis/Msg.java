package YosephShimelis;
public class Msg implements MessageInterface {
    @Override
    public void showMessages() {
        System.out.println("Thanks for working With us!!!");
    } 
}
