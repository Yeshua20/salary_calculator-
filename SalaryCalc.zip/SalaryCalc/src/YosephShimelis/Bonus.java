package YosephShimelis;

public class Bonus extends Manager {

@Override
public double calculate_overtime() {
        super.calculate_overtime();
        return overtime;
    }
}

