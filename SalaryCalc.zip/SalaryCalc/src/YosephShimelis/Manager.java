package YosephShimelis;
public abstract class Manager extends Main {
    double overtime;
    double bonus_rate=5;
    public double calculate_overtime(){
        this.overtime=bonus_rate;
        return 0;
    }   
    
}
